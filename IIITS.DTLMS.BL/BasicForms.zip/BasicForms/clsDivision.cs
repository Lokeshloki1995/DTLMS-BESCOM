﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using IIITS.DAL;
using System.Data;


namespace IIITS.DTLMS.BL
{
   public  class clsDivision
    {
        CustOledbConnection objcon = new CustOledbConnection(Constants.Password);
        public string sCircleCode { get; set; }
        public string sDivisionCode { get; set; }
        public string sDivisionName { get; set; }
        public string sName { get; set; }
        public string sPhone { get; set; }
        public string sMobileNo { get; set; }
        public string sEmail { get; set; }
        public string sMaxid { get; set; }


        public string[] SaveDivision(clsDivision objDivision)
        {
            string[] Arr = new string[2];
            try
            {

                string strQry = string.Empty;
                if (objDivision.sMaxid == "")
                {
                    OleDbDataReader dr = objcon.Fetch("Select * from TBLDIVISION where DIV_CODE='" + objDivision.sDivisionCode + "'");
                    if (dr.Read())
                    {
                        dr.Close();
                        Arr[0] = "division code already exists";
                        Arr[1] = "3";
                        return Arr;
                    }
                    dr.Close();

                    objDivision.sMaxid = objcon.Get_max_no("DIV_ID", "TBLDIVISION").ToString();

                    strQry = "INSERT INTO TBLDIVISION(DIV_ID, DIV_CODE ,DIV_NAME,DIV_CICLE_CODE,DIV_HEAD_EMP,DIV_MOBILE_NO,DIV_PHONE,DIV_EMAIL)";
                    strQry += "VALUES('"+objDivision.sMaxid+"', '" + objDivision.sDivisionCode + "','" + objDivision.sDivisionName + "','" + objDivision.sCircleCode + "',";
                    strQry += "'" + objDivision.sName + "','" + objDivision.sMobileNo + "','" + objDivision.sPhone + "','" + objDivision.sEmail + "'  )";
                    objcon.Execute(strQry);
                    Arr[0] = "Saved Successfully ";
                    Arr[1] = "0";
                    return Arr;
                }
                else
                {
                    strQry = " UPDATE TBLDIVISION SET DIV_NAME= '" + objDivision.sDivisionName + "', DIV_HEAD_EMP='" + objDivision.sName + "', DIV_CODE='" + objDivision.sDivisionCode + "'";
                    strQry += " ,DIV_MOBILE_NO='" + objDivision.sMobileNo + "', DIV_PHONE='" + objDivision.sPhone + "',DIV_EMAIL='" + objDivision.sEmail + "' where DIV_ID = '" + objDivision.sMaxid + "'";
                    objcon.Execute(strQry);
                    Arr[0] = "Updated Successfully ";
                    Arr[1] = "1";
                    return Arr;
                }
                return Arr;
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace, ex.Message, "clsDivision", "SaveDivision");
                return Arr;
            }
        }

        public DataTable LoadAllDivisionDetails()
        {
            DataTable dt = new DataTable();
            try
            {

                string strQry = string.Empty;
                strQry = "SELECT DIV_ID,  To_char(DIV_CODE)DIV_CODE ,DIV_NAME FROM TBLDIVISION";
                dt = objcon.getDataTable(strQry);
                return dt;
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace, ex.Message, "clsDivision", "LoadAllDivisionDetails");
                return dt;
            }

        }

        public object getDivisionDetails(clsDivision objDivision)
        {
            DataTable dtDetails = new DataTable();
            try
            {
                String strQry = "SELECT  DIV_CODE ,DIV_NAME,DIV_CICLE_CODE,DIV_HEAD_EMP,DIV_MOBILE_NO,DIV_PHONE,DIV_EMAIL FROM TBLDIVISION ";
                strQry += " WHERE DIV_ID ='" + objDivision.sMaxid + "'";
                dtDetails = objcon.getDataTable(strQry);

                if (dtDetails.Rows.Count > 0)
                {
                    objDivision.sDivisionName = Convert.ToString(dtDetails.Rows[0]["DIV_NAME"].ToString());
                    objDivision.sDivisionCode = Convert.ToString(dtDetails.Rows[0]["DIV_CODE"].ToString());
                    objDivision.sCircleCode = Convert.ToString(dtDetails.Rows[0]["DIV_CICLE_CODE"].ToString());
                    objDivision.sName = Convert.ToString(dtDetails.Rows[0]["DIV_HEAD_EMP"].ToString());
                    objDivision.sMobileNo = Convert.ToString(dtDetails.Rows[0]["DIV_MOBILE_NO"].ToString());
                    objDivision.sPhone = Convert.ToString(dtDetails.Rows[0]["DIV_PHONE"].ToString());
                    objDivision.sEmail = Convert.ToString(dtDetails.Rows[0]["DIV_EMAIL"].ToString());
                }
                return objDivision;
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace, ex.Message, "clsDivision", "getCircleDetails");
                return objDivision;
            }

        }




    }
}
