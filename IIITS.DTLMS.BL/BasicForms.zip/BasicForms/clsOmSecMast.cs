﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IIITS.DAL;
using System.Data.OleDb;
using System.Data;

namespace IIITS.DTLMS.BL
{

    public class clsOmSecMast
    {
        CustOledbConnection objCon = new CustOledbConnection(Constants.Password);
        string strQry = string.Empty;
        string strFormCode = "clsOmSecMast";




        public string[] SaveOmSecMastDetails(string strOmCode, string strOmName, string strSubDivCode, string strOmHeadEmp, string strOmMobile, string strUserLogged)
        {
            string[] Arrmsg = new string[2];
            try
            {

                OleDbDataReader dr = objCon.Fetch("select * from TBLOMSECMAST where OM_NAME='" + strOmName.Replace("'", "''") + "'");
                if (dr.Read())
                {
                    Arrmsg[0] = "OmSec With This Name Already Exists";
                    Arrmsg[1] = "4";
                    return Arrmsg;
                    
                }
                dr.Close();
                OleDbDataReader dr1 = objCon.Fetch("select * from TBLOMSECMAST where OM_CODE='" + strOmCode + "'");
                if (dr1.Read())
                {
                    Arrmsg[0] = "OmSec With This Code Already Exists";
                    Arrmsg[1] = "4";
                    return Arrmsg;
                   
                }
                dr1.Close();

              

                string strInsqry = "insert into TBLOMSECMAST(OM_SLNO,OM_CODE,OM_NAME,OM_SUBDIV_CODE,OM_HEAD_EMP,OM_MOBILE_NO,OM_ENTRY_AUTH)";
                strInsqry += " values(" + objCon.Get_max_no("OM_SLNO", "TBLOMSECMAST") + ",'" + strOmCode.ToUpper() + "','" + strOmName.ToUpper().Replace("'", "''") + "',";
               strInsqry += "  '" + strSubDivCode.ToUpper() + "','" + strOmHeadEmp.ToUpper().Replace("'", "''") + "','" + strOmMobile.ToUpper() + "','" + strUserLogged + "')";
                objCon.Execute(strInsqry);

                Arrmsg[0] = "O&M Section Information has been Saved Sucessfully.";
                Arrmsg[1] = "0";
                return Arrmsg;
               
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace,ex.Message, strFormCode, "SaveOmSecMastDetails");
                return Arrmsg;
            }
        }

        public string[] UpdateOmSecMastDetails(string strOldId, string strOmCode, string strOmName, string strSubDivCode, string strOmHeadEmp, string strOmMobile, string strUserLogged)
        {
            string[] Arrmsg = new string[2];
            try
            {
                OleDbDataReader dr = objCon.Fetch("select * from TBLOMSECMAST where OM_NAME='" + strOmName.Replace("'", "''") + "' and OM_SLNO<> '" + strOldId + "'");                
                if (dr.Read())
                {
                    Arrmsg[0] = "OmSec With This Name Already Exists";
                    Arrmsg[1] = "4";
                    return Arrmsg;
                }
                OleDbDataReader dr1 = objCon.Fetch("select * from TBLOMSECMAST where OM_CODE='" + strOmCode + "' and OM_SLNO<> '" + strOldId + "'");
                if (dr1.Read())
                {
                    Arrmsg[0] = "OmSec With This Code Already Exists";
                    Arrmsg[1] = "4";
                    return Arrmsg;
                }
                string strUpdqry = "update TBLOMSECMAST set OM_CODE='" + strOmCode.ToUpper() + "',OM_NAME ='" + strOmName.ToUpper().Replace("'", "''") + "',OM_SUBDIV_CODE='" + strSubDivCode.ToUpper() + "',OM_HEAD_EMP='" + strOmHeadEmp.ToUpper().Replace("'", "''") + "',OM_MOBILE_NO='" + strOmMobile.ToUpper() + "',OM_ENTRY_AUTH='" + strUserLogged + "',OM_ENTRY_DATE=SYSDATE where OM_SLNO = '" + strOldId.ToUpper() + "'";
                objCon.Execute(strUpdqry);

                Arrmsg[0] = "O&M Section Information has been Updated Sucessfully.";
                Arrmsg[1] = "0";
                return Arrmsg;
                            
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace,ex.Message, strFormCode, "UpdateOmSecMastDetails");
                return Arrmsg;
            }
        }

        public DataTable LoadOmSecvOffDet(string strOmSecID = "")
        {
            DataTable DtDivOffDet = new DataTable();
            try
            {
                strQry = "SELECT to_char(OM_SLNO) OM_SLNO,To_char(OM_CODE)OM_CODE,OM_NAME,OM_SUBDIV_CODE,";
               strQry += " SD_SUBDIV_NAME,OM_HEAD_EMP,OM_MOBILE_NO FROM TBLSUBDIVMAST,TBLOMSECMAST where OM_SUBDIV_CODE=SD_SUBDIV_CODE ";
                if (strOmSecID != "")
                {
                    strQry += " and OM_SLNO='" + strOmSecID + "'";
                }
                strQry += "  order by OM_CODE";
                OleDbDataReader drcorp = objCon.Fetch(strQry);
                DtDivOffDet.Load(drcorp);

                return DtDivOffDet;
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace,ex.Message, strFormCode, "LoadOmSecvOffDet");
                return DtDivOffDet;
            }
          }


    }
}




