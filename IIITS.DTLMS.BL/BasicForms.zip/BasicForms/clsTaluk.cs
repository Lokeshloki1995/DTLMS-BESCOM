﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;
using IIITS.DAL;

namespace IIITS.DTLMS.BL
{
    public class clsTaluk
    {
        string sformcode = "ClsTaluk";
        CustOledbConnection objcon = new CustOledbConnection(Constants.Password);
        public string sTalukId { get; set; }
        public string sDistrictName { get; set; }
        public string sTalukCode { get; set; }
        public string sTalukName { get; set; }
        public string sButtonName { get; set; }

        public string[] SaveDetails(clsTaluk objTlk)
        {
            string[] Arr = new string[3];
            string strQry = string.Empty;
            DataTable dt = new DataTable();
            try
            {
                if (objTlk.sButtonName == "Save")
                {
                    if (objTlk.sTalukId == "")
                    {
                        strQry = "select * from TBLTALQ where UPPER(TQ_CODE)='" + objTlk.sTalukCode.ToUpper() + "'";
                        dt = objcon.getDataTable(strQry);
                        if (dt.Rows.Count > 0)
                        {
                            Arr[0] = "Taluk Code Exist ";
                            Arr[1] = "1";
                            return Arr;
                        }

                        strQry = "select * from TBLTALQ where UPPER(TQ_NAME)='" + objTlk.sTalukName.ToUpper() + "'";
                        dt = objcon.getDataTable(strQry);
                        if (dt.Rows.Count > 0)
                        {
                            Arr[0] = "Taluk Name Exist ";
                            Arr[1] = "1";
                            return Arr;
                        }

                        string SMaxid = objcon.Get_max_no("TQ_SLNO", "TBLTALQ").ToString();
                        strQry = "select DT_CODE from TBLDIST where DT_CODE='" + objTlk.sDistrictName + "'";
                        string sDistcode = objcon.get_value(strQry);
                        strQry = "insert into TBLTALQ (TQ_CODE,TQ_NAME,TQ_SLNO,TQ_DT_ID) ";
                        strQry += " values('" + objTlk.sTalukCode + "','" + objTlk.sTalukName.Trim().Replace(" ", "") + "',";
                        strQry += " '" + SMaxid + "','" + sDistcode + "')";
                        objcon.Execute(strQry);
                        Arr[0] = SMaxid.ToString();
                        Arr[1] = "2";
                        Arr[2] = "Saved Succesfully";
                    }

                    else
                    {
                                               
                            strQry = "select * from TBLDIST where DT_CODE='" + objTlk.sDistrictName + "'";
                            dt = objcon.getDataTable(strQry);
                            string sDistCode = Convert.ToString(dt.Rows[0]["DT_CODE"].ToString());

                            strQry = "select * from TBLTALQ where UPPER(TQ_CODE)='" + objTlk.sTalukCode.ToUpper() + "' and TQ_DT_ID='" + sDistCode + "'";
                            dt = objcon.getDataTable(strQry);

                            if (dt.Rows.Count > 0)
                            {
                                if (dt.Rows[0]["TQ_NAME"].ToString() == objTlk.sTalukName.Trim().Replace(" ", ""))
                                {
                                    Arr[0] = "Taluk Name Exist ";
                                    Arr[1] = "1";
                                    return Arr;
                                }
                                else
                                {
                                    strQry = "select DT_CODE from TBLDIST where DT_CODE='" + objTlk.sDistrictName + "'";
                                    string sDistcode = objcon.get_value(strQry);
                                    string updateQry = "update TBLTALQ set TQ_CODE='" + objTlk.sTalukCode + "',TQ_NAME='" + objTlk.sTalukName.Trim().Replace(" ", "") + "',";
                                   updateQry +=" TQ_DT_ID='" + sDistcode + "' where UPPER(TQ_SLNO)='" + objTlk.sTalukId + "'";
                                    objcon.Execute(updateQry);
                                    Arr[0] = "Updated Successfully ";
                                    Arr[1] = "3";
                                    return Arr;
                                }
                            }

                            else
                            {
                                string SMaxid = objcon.Get_max_no("TQ_SLNO", "TBLTALQ").ToString();
                                strQry = "select DT_CODE from TBLDIST where UPPER(DT_NAME)='" + objTlk.sDistrictName.ToUpper() + "'";
                                string sDistcode = objcon.get_value(strQry);
                                strQry = "insert into TBLTALQ (TQ_CODE,TQ_NAME,TQ_SLNO,TQ_DT_ID) values('" + objTlk.sTalukCode + "',";
                               strQry +=" '" + objTlk.sTalukName.Trim().Replace(" ", "") + "','" + SMaxid + "','" + sDistcode + "')";
                                objcon.Execute(strQry);
                                Arr[0] = SMaxid.ToString();
                                Arr[1] = "2";
                                Arr[2] = "Created new taluk code and name";
                            }
                        }
                    }


                else
                {
                    

                    strQry = "select DT_CODE from TBLDIST where DT_CODE='" + objTlk.sDistrictName + "'";
                    string sDistcode = objcon.get_value(strQry);
                    string updateQry = "update TBLTALQ set TQ_CODE='" + objTlk.sTalukCode + "',TQ_NAME='" + objTlk.sTalukName.Trim().Replace(" ", "") + "',";
                    updateQry += " TQ_DT_ID='" + sDistcode + "' where UPPER(TQ_SLNO)='" + objTlk.sTalukId + "'";
                    objcon.Execute(updateQry);
                    Arr[0] = "Updated Successfully ";
                    Arr[1] = "3";
                    return Arr;
                }
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace, ex.Message, sformcode, "SaveDetails");
            }
            return Arr;
        }

        public OleDbDataReader Fetchdata()
        {
            OleDbDataReader dr = null;
            try
            {
                string selQry = "select DT_NAME from TBLDIST";
                dr = objcon.Fetch(selQry);
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace, ex.Message, sformcode, "Fetchdata");
            }
            return dr;
        }

        public object GetTlkDetails(clsTaluk objTaluk)
        {
            string sDistId = string.Empty;
            DataTable dtDetails = new DataTable();
            try
            {

                String strQry = "SELECT * FROM TBLTALQ WHERE TQ_SLNO='"+objTaluk.sTalukId+"'";
                dtDetails = objcon.getDataTable(strQry);

                if (dtDetails.Rows.Count > 0)
                {
                    sDistId = Convert.ToString(dtDetails.Rows[0]["TQ_DT_ID"].ToString());
                    objTaluk.sTalukCode = Convert.ToString(dtDetails.Rows[0]["TQ_CODE"].ToString());
                    objTaluk.sTalukName = Convert.ToString(dtDetails.Rows[0]["TQ_NAME"].ToString());
                    objTaluk.sDistrictName = Convert.ToString(dtDetails.Rows[0]["TQ_DT_ID"].ToString());
                    //strQry = "SELECT * FROM TBLDIST WHERE DT_CODE='" + sDistId + "'";
                    //dtDetails = objcon.getDataTable(strQry);

                    //objTaluk.sDistrictName = dtDetails.Rows[0]["DT_NAME"].ToString();
                }
                return objTaluk;
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace, ex.Message, sformcode, "GetTalkDetails");
                return objTaluk;
            }
        }

        public DataTable LoadAllTalkDetails()
        {
            DataTable dt = new DataTable();
            try
            {

                string strQry = string.Empty;
                strQry = "SELECT TQ_SLNO,TQ_CODE,TQ_NAME,DT_NAME FROM TBLTALQ,TBLDIST WHERE DT_CODE=TQ_DT_ID ORDER BY TQ_SLNO";
                dt = objcon.getDataTable(strQry);
                return dt;
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace, ex.Message, sformcode, "LoadAllTalkDetails");
                return dt;
            }

        }
    }
}
