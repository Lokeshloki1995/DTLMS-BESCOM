﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;
using IIITS.DAL;

namespace IIITS.DTLMS.BL
{
   public class clsDistrict
    {
       string sformcode = "ClsDistrict";
       CustOledbConnection objcon = new CustOledbConnection(Constants.Password);
       public string sDistId { get; set; }
       public string sDistrictCode { get; set; }
       public string sDistrictName { get; set; }
       public string sButtonname { get; set; }


        public string[] SaveDetails(clsDistrict objDis)
        {
            string strQry=string.Empty;
            string[] Arr = new string[3];
            OleDbDataReader dr = null;
            try
            {

                    if (objDis.sDistId == "")
                    {
                        strQry = "select * from tbldist where UPPER(DT_CODE)='" + objDis.sDistrictCode.ToUpper() + "'";
                        dr = objcon.Fetch(strQry);
                        if (dr.Read())
                        {
                            Arr[0] = "District Code AlreadyExist ";
                            Arr[1] = "1";
                            return Arr;
                        }
                        dr.Close();

                        strQry = "select * from tbldist where UPPER(DT_NAME)='" + objDis.sDistrictName.ToUpper() + "'";
                        dr = objcon.Fetch(strQry);
                        if (dr.Read())
                        {
                            Arr[0] = "District Name AlreadyExist ";
                            Arr[1] = "1";
                            return Arr;
                        }
                        dr.Close();

                        objDis.sDistId = objcon.Get_max_no("DT_ID", "TBLDIST").ToString();
                        strQry = "insert into tbldist (DT_CODE,DT_NAME,DT_ID) values('" + objDis.sDistrictCode + "',";
                        strQry += "'" + objDis.sDistrictName.Trim().Replace(" ", "") + "','" + objDis.sDistId + "')";
                        objcon.Execute(strQry);
                        Arr[0] = "Saved Succesfully";
                        Arr[1] = "0";
                        return Arr;
                    }
                    else
                    {

                        strQry = "select * from tbldist where UPPER(DT_NAME)='" + objDis.sDistrictName.ToUpper() + "' and DT_CODE <> '" + objDis.sDistrictCode + "'";
                        dr = objcon.Fetch(strQry);
                        if (dr.Read())
                        {
                            Arr[0] = "District Name AlreadyExist ";
                            Arr[1] = "1";
                            return Arr;
                        }
                        dr.Close();

                        strQry = "update tbldist set ";
                        strQry += " DT_NAME='" + objDis.sDistrictName.Trim().Replace(" ", "") + "' where DT_ID='" + objDis.sDistId + "'";
                        objcon.Execute(strQry);
                        Arr[0] = "Updated Successfully ";
                        Arr[1] = "1";
                        return Arr;
                    }
              
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace, ex.Message, sformcode, "GetDistDetails");
            }
            return Arr;
        }

        public object GetDistDetails(clsDistrict objDistrict)
        {

            DataTable dtDetails = new DataTable();
            try
            {

                String strQry = "SELECT * FROM TBLDIST ";
                strQry += " WHERE DT_ID='" + objDistrict.sDistId + "'";
                dtDetails = objcon.getDataTable(strQry);

                if (dtDetails.Rows.Count > 0)
                {
                    objDistrict.sDistrictCode = Convert.ToString(dtDetails.Rows[0]["DT_CODE"].ToString());
                    objDistrict.sDistrictName = Convert.ToString(dtDetails.Rows[0]["DT_NAME"].ToString());
                }
                return objDistrict;
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace, ex.Message, sformcode, "GetDistDetails");
                return objDistrict;
            }
        }

        public DataTable LoadAllDistDetails()
        {
            DataTable dt = new DataTable();
            try
            {

                string strQry = string.Empty;
                strQry = "SELECT DT_ID,To_char(DT_CODE)DT_CODE,DT_NAME FROM TBLDIST ORDER BY DT_ID";
                dt = objcon.getDataTable(strQry);
                return dt;
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace, ex.Message, sformcode, "LoadAllDistDetails");
                return dt;
            }

        }

    }
}
