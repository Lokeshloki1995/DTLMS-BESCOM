﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using IIITS.DAL;
using System.Data;


namespace IIITS.DTLMS.BL
{
   public class clsStation
    {
        CustOledbConnection objCon = new CustOledbConnection(Constants.Password);
        public Int64 StationId { get; set; }
        public string OfficeCode { get; set; }
        public string StationCode { get; set; }   
        public string StationName { get; set; }
        public string Description { get; set; }
        public string UserLogged { get; set; }
        public string Capacity { get; set; }
        public string MobileNo { get; set; }
        public string EmailId { get; set; }
        public string StationParentID { get; set; }
        public string OfficeName { get; set; }
        public bool IsSave { get; set; }

        string strFormCode = "clsStation";
       
        public string[] SaveStationDetails(clsStation ObjStation)
        {
            string[] Arrmsg = new string[2];
            try
            {
                       
                if (ObjStation.IsSave)
                {
                     //Check For dup;licate Station Code
                    OleDbDataReader dr = objCon.Fetch("select ST_ID FROM TBLSTATION WHERE ST_STATION_CODE='" + ObjStation.StationCode + "'");
                    if (dr.Read())
                    {
                        Arrmsg[0] = "Station Code  Already Exist";
                        Arrmsg[1] = "4";
                        return Arrmsg;
                    }
                    dr.Close();

                    dr = objCon.Fetch("select * FROM TBLSTATION WHERE ST_NAME='" + ObjStation.StationName + "'");
                    if (dr.Read())
                    {
                        Arrmsg[0] = "Station Name  Already Exist";
                        Arrmsg[1] = "4";
                        return Arrmsg;
                    }
                    dr.Close();

                    long slno = objCon.Get_max_no("ST_ID", "TBLSTATION");
                    string strInsqry = "insert into TBLSTATION(ST_ID,ST_STATION_CODE,ST_NAME,ST_DESCRIPTION,ST_MOBILE_NO,ST_EMAILID,ST_OFF_CODE,ST_STC_CAP_ID,ST_ENTRY_AUTH,ST_PARENT_STATID) ";
                    strInsqry += " values('" + slno + "','" + ObjStation.StationCode + "', '" + ObjStation.StationName.Replace("'", "''") + "',";
                    strInsqry += " '" + ObjStation.Description.ToUpper().Replace("'", "''") + "' ,'" + ObjStation.MobileNo.Trim() + "','" + ObjStation.EmailId.Trim() + "', ";
                    strInsqry += " '" + ObjStation.OfficeCode + "','" + ObjStation.Capacity + "','" + ObjStation.UserLogged + "','"+ ObjStation.StationParentID +"')";
                    objCon.Execute(strInsqry);
                    Arrmsg[0] = "Station Information has been Saved Sucessfully.";
                    Arrmsg[1] = "0";
                    return Arrmsg;

                }
                else
                {
                    //Check For dup;licate Station Code
                    OleDbDataReader dr = objCon.Fetch("select ST_ID FROM TBLSTATION WHERE ST_STATION_CODE='" + ObjStation.StationCode + "' AND ST_ID<>'" + ObjStation.StationId + "'");
                    if (dr.Read())
                    {
                        Arrmsg[0] = "Station Code Already Exist";
                        Arrmsg[1] = "4";
                        return Arrmsg;
                    }
                    dr.Close();

                    dr = objCon.Fetch("select * FROM TBLSTATION WHERE ST_NAME='" + ObjStation.StationName + "' AND ST_ID<>'" + ObjStation.StationId + "'");
                    if (dr.Read())
                    {
                        Arrmsg[0] = "Station Name Already Exist";
                        Arrmsg[1] = "4";
                        return Arrmsg;
                    }
                    dr.Close();

                    string strUpdqry = "update TBLSTATION set ST_NAME='" + ObjStation.StationName.ToUpper().Replace("'", "''") + "',ST_STATION_CODE='" + ObjStation.StationCode + "',";
                    strUpdqry += " ST_DESCRIPTION='" + ObjStation.Description.Replace("'", "''") + "',ST_ENTRY_AUTH='" + ObjStation.UserLogged + "',ST_ENTRY_DATE=SYSDATE,";
                    strUpdqry += " ST_STC_CAP_ID='" + ObjStation.Capacity + "',ST_MOBILE_NO='" + ObjStation.MobileNo.Trim() + "',ST_EMAILID='" + ObjStation.EmailId.Trim() + "',";
                    strUpdqry += "  ST_PARENT_STATID='" + ObjStation.StationParentID + "'  where ST_ID = '" + ObjStation.StationId + "'";
                    objCon.Execute(strUpdqry);

                    Arrmsg[0] = "Station Information has been Updated Sucessfully.";
                    Arrmsg[1] = "0";
                    return Arrmsg;

                }
               
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace,ex.Message, strFormCode, "SaveStationDetails");
                return Arrmsg;
            }
        }




        public DataTable LoadStationDet(string strStationID="")
        {
            DataTable DtStationDet = new DataTable();
            try
            {
                 string strQry = string.Empty;
                 strQry = " SELECT ST_ID,TO_CHAR(ST_STATION_CODE) ST_STATION_CODE,ST_NAME,ST_DESCRIPTION,STC_CAP_VALUE,ST_PARENT_STATID ";
                 strQry += " FROM  (SELECT ST_ID,ST_STATION_CODE,ST_PARENT_STATID,ST_NAME,ST_DESCRIPTION,STC_CAP_VALUE";
                 strQry += " FROM TBLSTATION,TBLSTATIONCAPACITY  ";
                 strQry += " WHERE  ST_STC_CAP_ID=STC_CAP_ID";

               if (strStationID != "")
               {
                   strQry += " AND ST_ID='" + strStationID + "'";
               }
               strQry += "  ) GROUP BY ST_ID,ST_STATION_CODE,ST_NAME,ST_DESCRIPTION,STC_CAP_VALUE,ST_PARENT_STATID";
               OleDbDataReader drstation = objCon.Fetch(strQry);
               DtStationDet.Load(drstation);
               return DtStationDet;
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace,ex.Message, strFormCode, "LoadStationDet");
                return DtStationDet;
            }
        }


        public DataTable LoadStationDetail(string strStationID = "")
        {
            DataTable DtStationDet = new DataTable();
            try
            {
                string strQry = string.Empty;

               strQry = " SELECT ST_ID,ST_STATION_CODE,ST_NAME,ST_DESCRIPTION,ST_STC_CAP_ID, ST_MOBILE_NO, ST_EMAILID";
               strQry += " FROM  (SELECT ST_ID,ST_STATION_CODE,ST_NAME,ST_DESCRIPTION,ST_STC_CAP_ID,";
               strQry += "  ST_MOBILE_NO, ST_EMAILID   FROM TBLSTATION";

                if (strStationID != "")
                {
                    strQry += " WHERE ST_ID='" + strStationID + "'";
                }
                strQry += "  ) GROUP BY ST_ID,ST_STATION_CODE,ST_NAME,ST_DESCRIPTION,ST_STC_CAP_ID, ST_MOBILE_NO, ST_EMAILID";
                OleDbDataReader drstation = objCon.Fetch(strQry);
                DtStationDet.Load(drstation);
                return DtStationDet;
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace,ex.Message, strFormCode, "LoadStationDetail");
                return DtStationDet;
            }
        }


        public DataTable LoadOfficeDet(clsStation objStation)
        {
            DataTable DtStationDet = new DataTable();
            try
            {
                string strQry = string.Empty;

                strQry = "select OFF_CODE,OFF_NAME FROM VIEW_ALL_OFFICES WHERE  OFF_CODE IS NOT NULL ";
                if (objStation.OfficeCode != "")
                {
                    strQry += " AND OFF_CODE LIKE '"+ objStation.OfficeCode +"'";
                }
                if (objStation.OfficeName  != "")
                {
                    strQry += " AND OFF_NAME LIKE '" + objStation.OfficeName + "'";
                }
                strQry+= " order by OFF_CODE";
                OleDbDataReader drstat = objCon.Fetch(strQry);
                DtStationDet.Load(drstat);
                return DtStationDet;
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace,ex.Message, strFormCode, "LoadOfficeDet");
                return DtStationDet;
            }
        }



    }
}

