﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;
using IIITS.DAL;

namespace IIITS.DTLMS.BL
{
    public class clsCircle
    {
        CustOledbConnection objcon = new CustOledbConnection(Constants.Password);
     
        public string sCircleCode { get; set; }
        public string sCircleName { get; set; }
        public string sName { get; set; }
        public string sPhone { get; set; }
        public string sMobileNo { get; set; }
        public string sEmail { get; set; }
        public string sMaxid { get; set; }

        public string[] SaveCircle(clsCircle objCircle)
        {
            string[] Arr = new string[2];
            try
            {
                string strQry = string.Empty;
                if (objCircle.sMaxid == "")
                {
                    objCircle.sMaxid = objcon.Get_max_no("CM_ID", "TBLCIRCLE").ToString();
                    OleDbDataReader dr = objcon.Fetch("Select * from TBLCIRCLE where UPPER(CM_CIRCLE_NAME) ='" + objCircle.sCircleName.ToUpper() + "'");
                    if (dr.Read())
                    {
                        dr.Close();
                        Arr[0] = "Circle Name already exists";
                        Arr[1] = "3";
                        return Arr;
                    }
                    dr.Close();

                    dr = objcon.Fetch("Select * from TBLCIRCLE where UPPER(CM_CIRCLE_CODE) ='" + objCircle.sCircleCode.ToUpper() + "'");
                    if (dr.Read())
                    {
                        dr.Close();
                        Arr[0] = "Circle Code already exists";
                        Arr[1] = "3";
                        return Arr;
                    }
                    dr.Close();

                    strQry = "INSERT INTO TBLCIRCLE(CM_ID, CM_CIRCLE_CODE ,CM_CIRCLE_NAME,CM_ZO_ID,CM_HEAD_EMP,CM_MOBILE_NO,CM_PHONE,CM_EMAIL)";
                    strQry += "VALUES('" + objCircle.sMaxid + "','" + objCircle.sCircleCode + "',";
                    strQry += " '" + objCircle.sCircleName + "',1,'" + objCircle.sName + "',";
                    strQry += " '" + objCircle.sMobileNo + "','" + objCircle.sPhone + "','" + objCircle.sEmail + "'  )";
                    objcon.Execute(strQry);
                    Arr[0] = "Saved Successfully ";
                    Arr[1] = "0";
                    return Arr;
                }
                else
                {
                    OleDbDataReader dr = objcon.Fetch("Select * from TBLCIRCLE where UPPER(CM_CIRCLE_NAME) ='" + objCircle.sCircleName.ToUpper() + "' and CM_ID  <> '" + objCircle.sMaxid + "'");
                    if (dr.Read())
                    {
                        dr.Close();
                        Arr[0] = "Circle Name already exists";
                        Arr[1] = "3";
                        return Arr;
                    }
                    dr.Close();

                    dr = objcon.Fetch("Select * from TBLCIRCLE where UPPER(CM_CIRCLE_CODE) ='" + objCircle.sCircleCode.ToUpper() + "' and CM_ID <> '" + objCircle.sMaxid + "'");
                    if (dr.Read())
                    {
                        dr.Close();
                        Arr[0] = "Circle Code already exists";
                        Arr[1] = "3";
                        return Arr;
                    }
                    dr.Close();

                    strQry = " UPDATE TBLCIRCLE SET CM_CIRCLE_CODE='" + objCircle.sCircleCode + "', CM_CIRCLE_NAME= '" + objCircle.sCircleName + "', ";
                    strQry += " CM_HEAD_EMP='" + objCircle.sName + "',CM_MOBILE_NO='" + objCircle.sMobileNo + "', CM_PHONE='" + objCircle.sPhone + "',";
                    strQry += " CM_EMAIL='" + objCircle.sEmail + "' WHERE CM_ID = '" + objCircle.sMaxid + "' ";
                    objcon.Execute(strQry);
                    Arr[0] = "Updated Successfully ";
                    Arr[1] = "1";
                    return Arr;
                }
                return Arr;
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace, ex.Message, "clsCircle", "SaveCircle");
                return Arr;
            }
        }

        public DataTable LoadAllCircleDetails()
        {
            DataTable dt = new DataTable();
            try
            {
                string strQry = string.Empty;
                strQry = "SELECT CM_ID, To_char(CM_CIRCLE_CODE)CM_CIRCLE_CODE ,CM_CIRCLE_NAME FROM TBLCIRCLE";
                dt = objcon.getDataTable(strQry);
                return dt;
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace, ex.Message, "clsCircle", "LoadAllCircleDetails");
                return dt;
            }

        }

        public object getCircleDetails(clsCircle objCircle)
        {
            DataTable dtDetails = new DataTable();
            OleDbDataReader dr = null;
            try
            {

                String strQry = "SELECT CM_CIRCLE_CODE ,CM_CIRCLE_NAME,CM_HEAD_EMP,CM_MOBILE_NO,CM_PHONE,CM_EMAIL FROM TBLCIRCLE ";
                strQry += " WHERE CM_ID ='" + objCircle.sMaxid + "'";
                dr = objcon.Fetch(strQry);
                dtDetails.Load(dr);

                if (dtDetails.Rows.Count > 0)
                {
                    objCircle.sCircleName = Convert.ToString(dtDetails.Rows[0]["CM_CIRCLE_NAME"].ToString());
                    objCircle.sName = Convert.ToString(dtDetails.Rows[0]["CM_HEAD_EMP"].ToString());
                    objCircle.sMobileNo = Convert.ToString(dtDetails.Rows[0]["CM_MOBILE_NO"].ToString());
                    objCircle.sPhone = Convert.ToString(dtDetails.Rows[0]["CM_PHONE"].ToString());
                    objCircle.sEmail = Convert.ToString(dtDetails.Rows[0]["CM_EMAIL"].ToString());
                    objCircle.sCircleCode = Convert.ToString(dtDetails.Rows[0]["CM_CIRCLE_CODE"].ToString());
                }
                return objCircle;
            }


            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace, ex.Message, "clsCircle", "getCircleDetails");
                return objCircle;
            }

        }



    }
}
