﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using IIITS.DAL;
using System.Data;
using System.Data.OleDb;

namespace IIITS.DTLMS.BL
{
   public class clsSubDiv
    {
       string strQry = string.Empty;
       string strFormCode = "clsSubDiv";
       CustOledbConnection objCon = new CustOledbConnection(Constants.Password);
       public string[] SaveUpdateSubDivisionDetails(string strSubDivID, string strDivCode, string strSubDivCode, string strName, string strHead, string strMobile, string strPhone, string strEmail, bool IsSave, string strUserLogged)
        {
            string[] Arrmsg = new string[2];
            try
            {
               
                if (IsSave)
                {
                    OleDbDataReader drchk = objCon.Fetch("select * from TBLSUBDIVMAST where SD_SUBDIV_CODE='" + strSubDivCode + "'");
                    if (drchk.Read())
                    {
                        Arrmsg[0] = "Sub Division Code Already exists";
                        Arrmsg[1] = "4";
                        return Arrmsg;
                    }
                    drchk.Close();
                    drchk = objCon.Fetch("select * from TBLSUBDIVMAST where UPPER(SD_SUBDIV_NAME)='" + strName.ToUpper().Replace("'", "''") + "'and SD_DIV_CODE ='" + strDivCode + "'  ");
                    if (drchk.Read())
                    {
                        Arrmsg[0] = "Sub Division Name Already exists";
                        Arrmsg[1] = "4";
                        return Arrmsg;
                    }
                    drchk.Close();

                   
                    long MaxNo = objCon.Get_max_no("SD_ID", "TBLSUBDIVMAST");

                    string strInsQry = string.Empty;
                    strInsQry = "INSERT  into TBLSUBDIVMAST (SD_ID,SD_SUBDIV_CODE,SD_SUBDIV_NAME,SD_DIV_CODE,SD_HEAD_EMP,SD_MOBILE,SD_PHONE,SD_EMAIL,SD_ENTRY_AUTH) VALUES";
                    strInsQry += " ('" + MaxNo + "','" + strSubDivCode + "','" + strName.Trim().ToUpper().Replace("'", "''") + "','" + strDivCode + "','" + strHead.Trim().ToUpper() + "','" + strMobile + "',";
                    strInsQry += " '" + strPhone + "','" + strEmail + "','"+strUserLogged+"')";
                    objCon.Execute(strInsQry);

                    Arrmsg[0] = "SubDivision Details Saved Sucessfully";
                    Arrmsg[1] = "0";
                    return Arrmsg;
                  
                }
                else
                {



                    OleDbDataReader drchk = objCon.Fetch("select * from TBLSUBDIVMAST where UPPER(SD_SUBDIV_NAME)='" + strName.ToUpper().Replace("'", "''") + "'and SD_DIV_CODE ='" + strDivCode + "' and SD_ID <>'" + strSubDivID + "' ");
                    if (drchk.Read())
                    {
                        Arrmsg[0] = "Sub Division Name Already exists";
                        Arrmsg[1] = "4";
                        return Arrmsg;
                    }
                    drchk.Close();
                    string strUpdQuery = "Update TBLSUBDIVMAST set SD_SUBDIV_NAME='" + strName.Trim().ToUpper().Replace("'", "''") + "',SD_DIV_CODE='" + strDivCode + "',SD_HEAD_EMP='" + strHead.Trim().ToUpper().Replace("'", "''") + "',";
                    strUpdQuery += "SD_MOBILE='" + strMobile + "',SD_PHONE='" + strPhone + "',SD_EMAIL='" + strEmail + "',SD_SUBDIV_CODE='" + strSubDivCode + "',SD_ENTRY_AUTH='" + strUserLogged + "',SD_ENTRY_DATE=SYSDATE  where SD_ID='" + strSubDivID + "' ";
                    objCon.Execute(strUpdQuery);

                    Arrmsg[0] = "Sub Division Details Update Sucessfully";
                    Arrmsg[1] = "0";
                    return Arrmsg;
                    
                }
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace,ex.Message, strFormCode, "SaveUpdateSubDivisionDetails");
                return Arrmsg;
            }

        }

        public DataTable LoadSubDivOffDet(string strSubDivID = "")
        {
            DataTable DtDivOffDet = new DataTable();
            try
            {
                strQry = string.Empty;
                strQry = "select SD_ID,To_char(SD_SUBDIV_CODE)SD_SUBDIV_CODE,SD_SUBDIV_NAME,DIV_NAME,SD_HEAD_EMP,SD_DIV_CODE,SD_TQ_ID,";
                strQry += "  SD_PHONE,SD_MOBILE,SD_EMAIL,CM_CIRCLE_NAME ";
                strQry += " from TBLDIVISION,TBLSUBDIVMAST,TBLCIRCLE where SD_DIV_CODE=DIV_CODE  AND CM_CIRCLE_CODE= DIV_CICLE_CODE   ";
                if (strSubDivID != "")
                {
                    strQry += " and SD_ID='" + strSubDivID + "'";
                }
                strQry += " order by SD_SUBDIV_CODE";
                OleDbDataReader drcorp = objCon.Fetch(strQry);
                DtDivOffDet.Load(drcorp);

                return DtDivOffDet;
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace,ex.Message, strFormCode, "LoadSubDivOffDet");
                return DtDivOffDet;
            }
        }




    }
}
