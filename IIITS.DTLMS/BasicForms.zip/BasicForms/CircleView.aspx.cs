﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IIITS.DTLMS.BL;
using System.Data;
using System.Text.RegularExpressions;

namespace IIITS.DTLMS.BasicForms
{
    public partial class CircleView : System.Web.UI.Page
    {
        string strFormCode = "CircleView.aspx";
        clsSession objSession;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["clsSession"] == null || Session["clsSession"].ToString() == "")
            {
                Response.Redirect("~/Login.aspx", false);
            }

            objSession = (clsSession)Session["clsSession"];

            if (!IsPostBack)
            {
                CheckAccessRights("4");
                LoadCircleDetails();
            }
        }

        protected void cmdNewCircle_Click(object sender, EventArgs e)
        {
            try
            {
                //Check AccessRights
                bool bAccResult = CheckAccessRights("2");
                if (bAccResult == false)
                {
                    return;
                }
                Response.Redirect("Circle.aspx", false);
            }
            catch (Exception ex)
            {
                // lblMessage.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "cmdNewCircle_Click");
            }
        }


        public void LoadCircleDetails()
        {
            try
            {
                DataTable dt = new DataTable();
                clsCircle objCircle = new clsCircle();
                dt = objCircle.LoadAllCircleDetails();
                ViewState["Circle"] = dt;
                grdCirclemaster.DataSource = dt;
                grdCirclemaster.DataBind();

            }
            catch (Exception ex)
            {
                lblMessage.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "LoadCircleDetails");

            }
        }



        protected void grdCirclemaster_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                DataTable dt = new DataTable();
                grdCirclemaster.PageIndex = e.NewPageIndex;
                dt = (DataTable)ViewState["Circle"];
                grdCirclemaster.DataSource = dt;
                grdCirclemaster.DataBind();
            }
            catch (Exception ex)
            {
                lblMessage.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "grdCirclemaster_PageIndexChanging");
            }
        }


        protected void imgBtnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                //Check AccessRights
                bool bAccResult = CheckAccessRights("3");
                if (bAccResult == false)
                {
                    return;
                }

                ImageButton imgEdit = (ImageButton)sender;
                GridViewRow rw = (GridViewRow)imgEdit.NamingContainer;

                String CircleID = ((Label)rw.FindControl("lblCirId")).Text;
                CircleID = HttpUtility.UrlEncode(Genaral.UrlEncrypt(CircleID));

                Response.Redirect("Circle.aspx?CircleId=" + CircleID + "", false);


            }
            catch (Exception ex)
            {

                lblMessage.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "imgBtnEdit_Click");

            }

        }

        protected void grdCirclemaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {

                if (e.CommandName == "search")
                {
                    string sFilter = string.Empty;
                    DataView dv = new DataView();

                    GridViewRow row = (GridViewRow)(((ImageButton)e.CommandSource).NamingContainer);
                    TextBox txtCircleCode = (TextBox)row.FindControl("txtCircleCode");
                    TextBox txtCircleName = (TextBox)row.FindControl("txtCircleName");



                    DataTable dt = (DataTable)ViewState["Circle"];
                    dv = dt.DefaultView;

                    if (txtCircleCode.Text != "")
                    {
                        sFilter = "CM_CIRCLE_CODE Like '%" + txtCircleCode.Text.Replace("'", "'") + "%' AND";
                    }
                    if (txtCircleName.Text != "")
                    {
                        sFilter += " CM_CIRCLE_NAME Like '%" + txtCircleName.Text.Replace("'", "'") + "%' AND";
                    }

                    if (sFilter.Length > 0)
                    {
                        sFilter = sFilter.Remove(sFilter.Length - 3);
                        grdCirclemaster.PageIndex = 0;
                        dv.RowFilter = sFilter;
                        if (dv.Count > 0)
                        {
                            grdCirclemaster.DataSource = dv;
                            ViewState["Circle"] = dv.ToTable();
                            grdCirclemaster.DataBind();

                        }
                        else
                        {

                            ShowEmptyGrid();
                        }
                    }
                    else
                    {
                        LoadCircleDetails();
                    }


                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "grdTcMaster_RowCommand");

            }
        }


        public void ShowEmptyGrid()
        {
            try
            {
                DataTable dt = new DataTable();
                DataRow newRow = dt.NewRow();
                dt.Rows.Add(newRow);
                dt.Columns.Add("CM_ID");
                dt.Columns.Add("CM_CIRCLE_CODE");
                dt.Columns.Add("CM_CIRCLE_NAME");


                grdCirclemaster.DataSource = dt;
                grdCirclemaster.DataBind();

                int iColCount = grdCirclemaster.Rows[0].Cells.Count;
                grdCirclemaster.Rows[0].Cells.Clear();
                grdCirclemaster.Rows[0].Cells.Add(new TableCell());
                grdCirclemaster.Rows[0].Cells[0].ColumnSpan = iColCount;
                grdCirclemaster.Rows[0].Cells[0].Text = "No Records Found";

            }
            catch (Exception ex)
            {
                lblMessage.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "ShowEmptyGrid");

            }
        }

        #region Access Rights
        public bool CheckAccessRights(string sAccessType)
        {
            try
            {
                // 1---> ALL ; 2---> CREATE ;  3---> MODIFY/DELETE ; 4 ----> READ ONLY

                clsApproval objApproval = new clsApproval();

                objApproval.sFormName = "Circle";
                objApproval.sRoleId = objSession.RoleId;
                objApproval.sAccessType = "1" + "," + sAccessType;
                bool bResult = objApproval.CheckAccessRights(objApproval);
                if (bResult == false)
                {
                    if (sAccessType == "4")
                    {
                        Response.Redirect("~/UserRestrict.aspx", false);
                    }
                    else
                    {
                        ShowMsgBox("Sorry , You are not authorized to Access");
                    }
                }
                return bResult;

            }
            catch (Exception ex)
            {
                lblMessage.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "CheckAccessRights");
                return false;

            }
        }

        #endregion


        private void ShowMsgBox(string sMsg)
        {
            try
            {
                string sShowMsg = string.Empty;
                sShowMsg = "<script language=javascript> alert ('" + sMsg + "')</script>";
                this.Page.RegisterStartupScript("Msg", sShowMsg);
            }
            catch (Exception ex)
            {
                lblMessage.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "ShowMsgBox");
            }
        }
    }
}