﻿using System.Text.RegularExpressions;
using System.IO;
using System.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IIITS.DTLMS.BL;
using System.Data;


namespace IIITS.DTLMS.BasicForms
{
    public partial class Station : System.Web.UI.Page
    {

        ArrayList userdetails = new ArrayList();
        string[] tmpuserlist = new string[50];
        string strUserLogged = string.Empty;
        string sFormCode = "Station";
        string strEmpId = string.Empty;
        clsSession objSession;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["clsSession"] == null || Session["clsSession"].ToString() == "")
                {
                    Response.Redirect("~/Login.aspx", false);
                }

                objSession = (clsSession)Session["clsSession"];
              

              
                lblErrormsg.Text = string.Empty;
                if (!IsPostBack)
                {

                    Genaral.Load_Combo("SELECT DT_CODE,DT_CODE || '-' || DT_NAME FROM TBLDIST ORDER BY DT_CODE", "--Select--", cmbDistrict);
                    Genaral.Load_Combo("SELECT STC_CAP_ID,STC_CAP_ID || '-' || STC_CAP_VALUE FROM TBLSTATIONCAPACITY ORDER BY STC_CAP_ID", "--Select--", cmbCapacity);

                    if (Request.QueryString["StationId"] != null && Request.QueryString["StationId"].ToString() != "")
                    {
                        txtStationId.Text = Genaral.UrlDecrypt(HttpUtility.UrlDecode(Request.QueryString["StationId"]));
                    }

                    if (txtStationId.Text != "0")
                    {

                        LoadStationDet(txtStationId.Text);
                        cmbDistrict_SelectedIndexChanged(sender, e);
                        cmbTalq.SelectedValue = Convert.ToString(txtStationCode.Text.Substring(0, 2));

                    }
                   }
            }
            catch (Exception ex)
            {
                lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace,ex.Message, sFormCode, "Page_Load");
            }
        }

        protected void cmdSave_Click(object sender, EventArgs e)
        {
            try
            {
                string[] Arrmsg = new string[2];

                strUserLogged = objSession.UserId;
                if (txtStatName.Text.Trim().Length == 0 )
                {
                     ShowMsgBox("Enter Station Name");
                     txtStatName.Focus();
                    return;
                }
                if (cmbDistrict.SelectedValue == "0")
                {
                     ShowMsgBox("Select District");
                     cmbDistrict.Focus();
                    return;
                }
                if (cmbTalq.SelectedValue == "0")
                {
                     ShowMsgBox("Select Taluk");
                     cmbTalq.Focus();
                    return;
                }

                if (txtStationCode.Text.Trim().Length == 0)
                {
                    ShowMsgBox("Enter Station Code");
                    txtStationCode.Focus();
                    return;
                }
                if (txtStationCode.Text.Length != 3)
                {
                     ShowMsgBox("Station Code should be 3 digits");
                     txtStationCode.Focus();
                    return;
                }
                if (cmbDistrict.SelectedValue.ToString() != txtStationCode.Text.Substring(0, 1))
                {
                    ShowMsgBox("District Code and Station Code Does not Match");
                    txtStationCode.Focus();
                    return;
                }


                if (cmbTalq.SelectedValue.ToString() != txtStationCode.Text.Substring(0, 2))
                {
                    ShowMsgBox("Taluk Code and Station Code Does not Match");
                    txtStationCode.Focus();
                    return;
                }

                if (cmbCapacity.SelectedIndex==0)
                {
                     ShowMsgBox("Select the required Voltage Class");
                     cmbCapacity.Focus();
                    return;
                }
                if (txtMobileNo.Text.Trim().Length == 0)
                {
                   ShowMsgBox("Enter Valid Mobile Number");
                   txtMobileNo.Focus();
                    return;
                }
                if (txtMobileNo.Text.Length != 10)
                {
                    ShowMsgBox("Enter Valid 10 Digit Mobile Number");
                    txtMobileNo.Focus();
                    return;
                }
                if (txtEmailId.Text.Trim().Length == 0)
                {
                     ShowMsgBox("Enter Valid Email Id");
                     txtEmailId.Focus();
                    return;
                }
                if (!System.Text.RegularExpressions.Regex.IsMatch(txtEmailId.Text, "^\\s*[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+[a-zA-Z0-9]\\s*$"))
                {
                     ShowMsgBox("Please enter Valid Email (xyz@aaa.com)");
                     txtEmailId.Focus();
                    return ;
                }

                clsStation objStation = new clsStation();
                objStation.StationId = Convert.ToInt64(txtStationId.Text);
                objStation.StationName = txtStatName.Text.Trim();
                objStation.StationCode = txtStationCode.Text.Trim();
                objStation.EmailId = txtEmailId.Text.Trim();
                objStation.MobileNo = txtMobileNo.Text.Trim();
              

                objStation.UserLogged = strUserLogged;
              
                
                objStation.Description = txtDesc.Text.Trim();
                objStation.Capacity = cmbCapacity.SelectedValue;

                if (cmdSave.Text.Equals("Save"))
                {
                    objStation.IsSave = true;
                    Arrmsg = objStation.SaveStationDetails(objStation);
                    if (Arrmsg[1].ToString() == "0")
                    {
                        ShowMsgBox(Arrmsg[0]);

                        Reset();
                    }
                    if (Arrmsg[1].ToString() == "4")
                    {
                        ShowMsgBox(Arrmsg[0]);
                    }

                }
                if (cmdSave.Text.Equals("Update"))
                {
                    objStation.IsSave = false;
                    Arrmsg = objStation.SaveStationDetails(objStation);
                    if (Arrmsg[1].ToString() == "0")
                    {
                        ShowMsgBox(Arrmsg[0]);

                        Reset();
                    }
                    if (Arrmsg[1].ToString() == "4")
                    {
                        ShowMsgBox(Arrmsg[0]);
                    }
                }


                //LoadStation();
            }
            catch (Exception ex)
            {
                lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace,ex.Message, sFormCode, "cmdSave_Click");
            }
        }

        private void ShowMsgBox(string sMsg)
        {
            try
            {
                string sShowMsg = string.Empty;
                sShowMsg = "<script language=javascript> alert ('" + sMsg + "')</script>";
                this.Page.RegisterStartupScript("Msg", sShowMsg);
            }
            catch (Exception ex)
            {
                Response.Write(ex);
                lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, sFormCode, "ShowMsgBox");
            }
        }

        /// <summary>
        /// Reset Fn
        /// </summary>
        private void Reset()
        {
            try
            {
                txtStationCode.Text = string.Empty;
                txtStatName.Text = string.Empty;
                txtDesc.Text = string.Empty;
                userdetails.Clear();
                cmbDistrict.SelectedIndex = 0;
                cmbTalq.SelectedIndex = 0;
                txtMobileNo.Text = string.Empty;
                txtEmailId.Text = string.Empty;
                cmdSave.Text = "Save";
                cmbCapacity.SelectedIndex = 0;
                cmbDistrict.Enabled = true;
                cmbTalq.Enabled = true;
                txtStationCode.Enabled = true;
             
                
            }
            catch (Exception ex)
            {
                lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace,ex.Message, sFormCode, "Reset");
            }

        }

        public void LoadStationDet(string strStationId)
        {
            try
            {
                clsStation ObjStation = new clsStation();
                ArrayList arrOffCode = new ArrayList();
                ArrayList arrOffCodeValue = new ArrayList();

                DataTable DtStationDet = ObjStation.LoadStationDetail(strStationId);

                txtStatName.Text = Convert.ToString(DtStationDet.Rows[0]["ST_NAME"]);
                txtStationCode.Text = Convert.ToString(DtStationDet.Rows[0]["ST_STATION_CODE"]);
                txtDesc.Text = Convert.ToString(DtStationDet.Rows[0]["ST_DESCRIPTION"]);
               
                txtMobileNo.Text = Convert.ToString(DtStationDet.Rows[0]["ST_MOBILE_NO"]);
                txtEmailId.Text = Convert.ToString(DtStationDet.Rows[0]["ST_EMAILID"]);
               
                cmbCapacity.SelectedValue = Convert.ToString(DtStationDet.Rows[0]["ST_STC_CAP_ID"]);              
                cmbDistrict.SelectedValue = Convert.ToString(txtStationCode.Text.Substring(0, 1));
                cmbTalq.SelectedValue = Convert.ToString(txtStationCode.Text.Substring(0, 2));

                cmbDistrict.Enabled = false;
                cmbTalq.Enabled = false;
                txtStationCode.Enabled = false;
                ViewState["CHECKED_ITEMS"] = arrOffCodeValue;

                LoadOffice();
              

                
                cmdSave.Text = "Update";
              

            }
            catch (Exception ex)
            {
                lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace,ex.Message, sFormCode, "LoadStationDet");
            }

        }

        protected void cmdReset_Click1(object sender, EventArgs e)
        {
            Reset();
        }

        public void LoadOffice(string sOfficeCode="",string sOffName="")
        {
            try
            {
                DataTable dtPageDetaiils = new DataTable();
                clsStation objStation = new clsStation();
                objStation.OfficeCode = sOfficeCode;
                objStation.OfficeName = sOffName;
                dtPageDetaiils = objStation.LoadOfficeDet(objStation);
              
            }
            catch (Exception ex)
            {
                lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace,ex.Message, sFormCode, "LoadOffice");
            }
        }

        protected void cmbDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbDistrict.SelectedIndex > 0)
                {
                    Genaral.Load_Combo(" SELECT TQ_CODE,TQ_CODE || '-' || TQ_NAME FROM TBLTALQ WHERE TQ_DT_ID like '" + cmbDistrict.SelectedValue + "%'  order by TQ_CODE", "--Select--", cmbTalq);
                }
            }
            catch (Exception ex)
            {
                lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace,ex.Message, sFormCode, "cmbDistrict_SelectedIndexChanged");
            }
        }

        protected void cmdParentStID_Click(object sender, EventArgs e)
        {
          
            string strLocationId = string.Empty;
            strLocationId += "Title=Search Window&";


            string strDeviceId = string.Empty;



            strEmpId += "Title=Search and Select Parent station Details&";


            strEmpId += "Query=select ST_ID \"StationID\",ST_NAME \"StationName\",ST_STATION_CODE \"StationCode\" FROM   TBLSTATION,TBLSTATIONCAPACITY  WHERE ST_STC_CAP_ID=STC_CAP_ID  and STC_CAP_ID>" + cmbCapacity.SelectedValue + " and  LOWER({0}) like %{1}% order by ST_NAME&";
            strEmpId += "DBColName=ST_NAME~ST_STATION_CODE&";
            strEmpId += "ColDisplayName=StationName~StationCode&";
          
        }

        #region Access Rights
        public bool CheckAccessRights(string sAccessType)
        {
            try
            {
                // 1---> ALL ; 2---> CREATE ;  3---> MODIFY/DELETE ; 4 ----> READ ONLY

                clsApproval objApproval = new clsApproval();

                objApproval.sFormName = "Station";
                objApproval.sRoleId = objSession.RoleId;
                objApproval.sAccessType = "1" + "," + sAccessType;
                bool bResult = objApproval.CheckAccessRights(objApproval);
                if (bResult == false)
                {
                    if (sAccessType == "4")
                    {
                        Response.Redirect("~/UserRestrict.aspx", false);
                    }
                    else
                    {
                        ShowMsgBox("Sorry , You are not authorized to Access");
                    }
                }
                return bResult;

            }
            catch (Exception ex)
            {
                lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, sFormCode, "CheckAccessRights");
                return false;

            }
        }

        #endregion

    }
}
        
    



      
  
