﻿using System.Text.RegularExpressions;
using System.IO;
using System.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IIITS.DTLMS.BL;
using System.Data;

namespace IIITS.DTLMS.BasicForms
{
    public partial class StationView : System.Web.UI.Page
    {
        static string strStationId = "0";
        string sFormCode = "StationView";
        clsSession objSession;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["clsSession"] == null || Session["clsSession"].ToString() == "")
                {
                    Response.Redirect("~/Login.aspx", false);
                }

                objSession = (clsSession)Session["clsSession"];


                if (!IsPostBack)
                {
                    CheckAccessRights("4");
                    LoadStation();
                }
            }
            catch (Exception ex)
            {
                lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, sFormCode, "Page_Load");
            }
        }

        public void LoadStation()
        {
            try
            {
                clsStation objStation = new clsStation();
                DataTable dt = new DataTable();
                dt = objStation.LoadStationDet();
                grdStation.DataSource = dt;
                grdStation.DataBind();
                ViewState["Station"] = dt;
            }
            catch (Exception ex)
            {
                lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, sFormCode, "LoadStation");
            }
        }

        protected void imgBtnEdit_Click(object sender, ImageClickEventArgs e)
        {
            try
            {

                //Check AccessRights
                bool bAccResult = CheckAccessRights("3");
                if (bAccResult == false)
                {
                    return;
                }


                ImageButton imgEdit = (ImageButton)sender;
                GridViewRow rw = (GridViewRow)imgEdit.NamingContainer;

                strStationId = (((HiddenField)rw.FindControl("hfID")).Value.ToString());
                strStationId = HttpUtility.UrlEncode(Genaral.UrlEncrypt(strStationId));
                Response.Redirect("Station.aspx?StationId=" + strStationId + "", false);

            }
            catch (Exception ex)
            {
                lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, sFormCode, "imgBtnEdit_Click");
            }

        }

        /// <summary>
        /// protected void imbBtnDelete_Click(object sender, ImageClickEventArgs e)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void imbBtnDelete_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton imgDel = (ImageButton)sender;
            GridViewRow rw = (GridViewRow)imgDel.NamingContainer;


        }

        protected void grdStation_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdStation.PageIndex = e.NewPageIndex;
                DataTable dt = (DataTable)ViewState["Station"];
                grdStation.DataSource = dt;
                grdStation.DataBind();
            }
            catch (Exception ex)
            {
                lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, sFormCode, "grdStation_PageIndexChanging");
            }

        }

        protected void grdStation_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "search")
                {
                    GridViewRow row = (GridViewRow)((ImageButton)e.CommandSource).NamingContainer;

                    TextBox txtStationName = (TextBox)row.FindControl("txtStationName");
                    TextBox txtStationCode = (TextBox)row.FindControl("txtStationCode");

                    DataTable dt = (DataTable)ViewState["Station"];
                    DataView dv = new DataView();
                    dv.Table = dt;
                    string sFilter = string.Empty;
                    if (txtStationName.Text != "")
                    {
                        sFilter = " ST_NAME like '" + txtStationName.Text.Trim().ToUpper() + "%' AND";
                    }

                    if (sFilter.Length > 0)
                    {
                        sFilter = sFilter.Remove(sFilter.Length - 3);
                        grdStation.PageIndex = 0;
                        dv.RowFilter = sFilter;
                        if (dv.Count > 0)
                        {
                            grdStation.DataSource = dv;
                            ViewState["Station"] = dv.ToTable();
                            grdStation.DataBind();

                        }
                        else
                        {

                            ShowEmptyGrid();
                        }
                    }
                    else
                    {
                        grdStation.DataSource = dv;
                        grdStation.DataBind();
                    }


                }
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace, ex.Message, sFormCode, "grdStation_RowCommand");
            }
        }


        public void ShowEmptyGrid()
        {
            try
            {
                DataTable dt = new DataTable();
                DataRow newRow = dt.NewRow();
                dt.Rows.Add(newRow);
                dt.Columns.Add("ST_ID");
                dt.Columns.Add("ST_NAME");
                dt.Columns.Add("ST_STATION_CODE");
                dt.Columns.Add("STC_CAP_VALUE");
                dt.Columns.Add("OFFNAME");
                dt.Columns.Add("ST_DESCRIPTION");

                grdStation.DataSource = dt;
                grdStation.DataBind();

                int iColCount = grdStation.Rows[0].Cells.Count;
                grdStation.Rows[0].Cells.Clear();
                grdStation.Rows[0].Cells.Add(new TableCell());
                grdStation.Rows[0].Cells[0].ColumnSpan = iColCount;
                grdStation.Rows[0].Cells[0].Text = "No Records Found";

            }
            catch (Exception ex)
            {

                clsException.LogError(ex.StackTrace, ex.Message, sFormCode, "ShowEmptyGrid");

            }
        }

        #region Access Rights
        public bool CheckAccessRights(string sAccessType)
        {
            try
            {
                // 1---> ALL ; 2---> CREATE ;  3---> MODIFY/DELETE ; 4 ----> READ ONLY

                clsApproval objApproval = new clsApproval();

                objApproval.sFormName = "Station";
                objApproval.sRoleId = objSession.RoleId;
                objApproval.sAccessType = "1" + "," + sAccessType;
                bool bResult = objApproval.CheckAccessRights(objApproval);
                if (bResult == false)
                {
                    if (sAccessType == "4")
                    {
                        Response.Redirect("~/UserRestrict.aspx", false);
                    }
                    else
                    {
                        ShowMsgBox("Sorry , You are not authorized to Access");
                    }
                }
                return bResult;

            }
            catch (Exception ex)
            {
                lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, sFormCode, "CheckAccessRights");
                return false;

            }
        }

        #endregion

        private void ShowMsgBox(string sMsg)
        {
            try
            {
                string sShowMsg = string.Empty;
                sShowMsg = "<script language=javascript> alert ('" + sMsg + "')</script>";
                this.Page.RegisterStartupScript("Msg", sShowMsg);
            }
            catch (Exception ex)
            {
                lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, sFormCode, "ShowMsgBox");
            }
        }

        protected void cmdNewStation_Click(object sender, EventArgs e)
        {
            try
            {
                //Check AccessRights
                bool bAccResult = CheckAccessRights("2");
                if (bAccResult == false)
                {
                    return;
                }
                Response.Redirect("Station.aspx", false);

            }
            catch (Exception ex)
            {
                lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, sFormCode, "cmdNewStation_Click");
            }
        }
    }
}