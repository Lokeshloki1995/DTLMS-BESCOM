﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IIITS.DTLMS.BL;
using System.Data;
using System.Text.RegularExpressions;


namespace IIITS.DTLMS.BasicForms
{
    public partial class TalukView : System.Web.UI.Page
    {
        string strFormCode = "TalukView";
        clsSession objSession;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["clsSession"] == null || Session["clsSession"].ToString() == "")
            {
                Response.Redirect("~/Login.aspx", false);
            }
            objSession = (clsSession)Session["clsSession"];

            if (!IsPostBack)
            {
                CheckAccessRights("4");
                LoadTalukDetails();
            }
        }

        protected void cmdNewTaluk_Click(object sender, EventArgs e)
        {
            try
            {
                //Check AccessRights
                bool bAccResult = CheckAccessRights("2");
                if (bAccResult == false)
                {
                    return;
                }

                Response.Redirect("Taluk.aspx", false);
            }
            catch (Exception ex)
            {
                lblMessage.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "cmdNewDistrict_Click");
            }
        }


        protected void imgBtnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                //Check AccessRights
                bool bAccResult = CheckAccessRights("3");
                if (bAccResult == false)
                {
                    return;
                }

                ImageButton imgEdit = (ImageButton)sender;
                GridViewRow rw = (GridViewRow)imgEdit.NamingContainer;

                String TalukCode = ((Label)rw.FindControl("lblTlkId")).Text;
                TalukCode = HttpUtility.UrlEncode(Genaral.UrlEncrypt(TalukCode));

                Response.Redirect("Taluk.aspx?TalukId=" + TalukCode + "", false);

            }
            catch (Exception ex)
            {
                lblMessage.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "imgBtnEdit_Click");
            }
        }

        public void LoadTalukDetails()
        {
            try
            {
                DataTable dt = new DataTable();
                clsTaluk objTalk = new clsTaluk();
                dt = objTalk.LoadAllTalkDetails();
                ViewState["TalkDetails"] = dt;
                grdTalukdetails.DataSource = dt;
                grdTalukdetails.DataBind();

            }
            catch (Exception ex)
            {
                lblMessage.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "LoadDistrictDetails");

            }
        }

        protected void grdTalukdetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                DataTable dt = new DataTable();
                grdTalukdetails.PageIndex = e.NewPageIndex;
                dt = (DataTable)ViewState["TalkDetails"];
                grdTalukdetails.DataSource = dt;
                grdTalukdetails.DataBind();
            }
            catch (Exception ex)
            {

                lblMessage.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "grdTalukdetails_PageIndexChanging");
            }
        }

        protected void grdTalukdetails_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "search")
                {
                    string sFilter = string.Empty;
                    DataView dv = new DataView();

                    GridViewRow row = (GridViewRow)(((ImageButton)e.CommandSource).NamingContainer);
                    TextBox txtDistName = (TextBox)row.FindControl("txtDistrictName");
                    TextBox txtTalukCode = (TextBox)row.FindControl("txtTalukCode");
                    DataTable dt = (DataTable)ViewState["TalkDetails"];
                    dv = dt.DefaultView;

                    if (txtDistName.Text != "")
                    {
                        sFilter += " DT_NAME Like '%" + txtDistName.Text.Replace("'", "'") + "%' AND";
                    }
                    if (txtTalukCode.Text != "")
                    {
                        sFilter += " TQ_CODE Like '%" + txtTalukCode.Text.Replace("'", "'") + "%' AND";
                    }
                    if (sFilter.Length > 0)
                    {
                        sFilter = sFilter.Remove(sFilter.Length - 3);
                        grdTalukdetails.PageIndex = 0;
                        dv.RowFilter = sFilter;
                        if (dv.Count > 0)
                        {
                            grdTalukdetails.DataSource = dv;
                            ViewState["TalkDetails"] = dv.ToTable();
                            grdTalukdetails.DataBind();

                        }
                        else
                        {

                            ShowEmptyGrid();
                        }
                    }
                    else
                    {
                        LoadTalukDetails();
                    }


                }
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "grdOmSection_RowCommand");
            }
        }


        public void ShowEmptyGrid()
        {
            try
            {
                DataTable dt = new DataTable();
                DataRow newRow = dt.NewRow();
                dt.Rows.Add(newRow);
                dt.Columns.Add("TQ_SLNO");
                dt.Columns.Add("DT_NAME");
                dt.Columns.Add("TQ_CODE");
                dt.Columns.Add("TQ_NAME");
              


                grdTalukdetails.DataSource = dt;
                grdTalukdetails.DataBind();

                int iColCount = grdTalukdetails.Rows[0].Cells.Count;
                grdTalukdetails.Rows[0].Cells.Clear();
                grdTalukdetails.Rows[0].Cells.Add(new TableCell());
                grdTalukdetails.Rows[0].Cells[0].ColumnSpan = iColCount;
                grdTalukdetails.Rows[0].Cells[0].Text = "No Records Found";

            }
            catch (Exception ex)
            {
                lblMessage.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "ShowEmptyGrid");

            }
        }

        #region Access Rights
        public bool CheckAccessRights(string sAccessType)
        {
            try
            {
                // 1---> ALL ; 2---> CREATE ;  3---> MODIFY/DELETE ; 4 ----> READ ONLY

                clsApproval objApproval = new clsApproval();

                objApproval.sFormName = "Taluk";
                objApproval.sRoleId = objSession.RoleId;
                objApproval.sAccessType = "1" + "," + sAccessType;
                bool bResult = objApproval.CheckAccessRights(objApproval);
                if (bResult == false)
                {
                    if (sAccessType == "4")
                    {
                        Response.Redirect("~/UserRestrict.aspx", false);
                    }
                    else
                    {
                        ShowMsgBox("Sorry , You are not authorized to Access");
                    }
                }
                return bResult;

            }
            catch (Exception ex)
            {
                //lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "CheckAccessRights");
                return false;

            }
        }

        #endregion


        private void ShowMsgBox(string sMsg)
        {
            try
            {
                string sShowMsg = string.Empty;
                sShowMsg = "<script language=javascript> alert ('" + sMsg + "')</script>";
                this.Page.RegisterStartupScript("Msg", sShowMsg);
            }
            catch (Exception ex)
            {
                //lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "ShowMsgBox");
            }
        }
    }
}