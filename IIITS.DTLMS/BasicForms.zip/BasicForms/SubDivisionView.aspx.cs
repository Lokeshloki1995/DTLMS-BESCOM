﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IIITS.DTLMS.BL;
using System.Data;
using System.Text.RegularExpressions;


namespace IIITS.DTLMS.BasicForms
{
    public partial class SubDivisionView : System.Web.UI.Page
    {
        string strFormCode = "SubDivisionView";
        clsSession objSession;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["clsSession"] == null || Session["clsSession"].ToString() == "")
            {
                Response.Redirect("~/Login.aspx", false);
            }

            objSession = (clsSession)Session["clsSession"];
            
            if (!IsPostBack)
            {
                CheckAccessRights("4");
                LoadSubDivisionOffices();
            }
        }

        public void LoadSubDivisionOffices()
        {
            try
            {
                clsSubDiv ObjSubDivOffice = new clsSubDiv();
                DataTable dt = new DataTable();
                dt = ObjSubDivOffice.LoadSubDivOffDet();
                grdZoneOffice.DataSource = dt;
                grdZoneOffice.DataBind();
                ViewState["SubDivision"] = dt;
            }
            catch (Exception ex)
            {

            }
        }
        protected void grdZoneOffice_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
          
            grdZoneOffice.PageIndex = e.NewPageIndex;
            DataTable dt = (DataTable)ViewState["SubDivision"];
            grdZoneOffice.DataSource = dt;
            grdZoneOffice.DataBind();
        }
        protected void imgBtnEdit_Click(object sender, ImageClickEventArgs e)
        {
            try
            {

                //Check AccessRights
                bool bAccResult = CheckAccessRights("3");
                if (bAccResult == false)
                {
                    return;
                }

                ImageButton imgEdit = (ImageButton)sender;
                GridViewRow rw = (GridViewRow)imgEdit.NamingContainer;

                String strSubDivisionId = (((HiddenField)rw.FindControl("hfID")).Value.ToString());
                strSubDivisionId = HttpUtility.UrlEncode(Genaral.UrlEncrypt(strSubDivisionId));

                Response.Redirect("SubDivision.aspx?SubDivId=" + strSubDivisionId + "", false);
            }
            catch (Exception ex)
            {

               //.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace,ex.Message, strFormCode, "imgBtnEdit_Click");
            }
        }
        protected void imbBtnDelete_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton imgDel = (ImageButton)sender;
            GridViewRow rw = (GridViewRow)imgDel.NamingContainer;
        }


        protected void cmdNewSubDivision_Click(object sender, EventArgs e)
        {
            try
            {
                //Check AccessRights
                bool bAccResult = CheckAccessRights("2");
                if (bAccResult == false)
                {
                    return;
                }
                Response.Redirect("SubDivision.aspx", false);
            }
            catch (Exception ex)
            {
                // lblMessage.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace,ex.Message, strFormCode, "cmdNewSubDivision_Click");
            }
        }

        protected void grdZoneOffice_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "search")
                {
                    string sFilter = string.Empty;
                    DataView dv = new DataView();

                    GridViewRow row = (GridViewRow)(((ImageButton)e.CommandSource).NamingContainer);
                    TextBox txtCircleName = (TextBox)row.FindControl("txtcircleName");
                    TextBox txtDivName = (TextBox)row.FindControl("txtDivisionName");
                    TextBox txtSubDivName = (TextBox)row.FindControl("txtsubDivisionName");
                    TextBox txtSubDivCode = (TextBox)row.FindControl("txtSubDivCode");

                    DataTable dt = (DataTable)ViewState["SubDivision"];
                    dv = dt.DefaultView;

                    if (txtCircleName.Text != "")
                    {
                        sFilter = "CM_CIRCLE_NAME Like '%" + txtCircleName.Text.Replace("'", "'") + "%' AND";
                    }
                    if (txtDivName.Text != "")
                    {
                        sFilter += " DIV_NAME Like '%" + txtDivName.Text.Replace("'", "'") + "%' AND";
                    }
                    if (txtSubDivName.Text != "")
                    {
                        sFilter += " SD_SUBDIV_NAME Like '%" + txtSubDivName.Text.Replace("'", "'") + "%' AND";
                    }
                    if (txtSubDivCode.Text != "")
                    {
                        sFilter += " SD_SUBDIV_CODE Like '%" + txtSubDivCode.Text.Replace("'", "'") + "%' AND";
                    }

                    if (sFilter.Length > 0)
                    {
                        sFilter = sFilter.Remove(sFilter.Length - 3);
                        grdZoneOffice.PageIndex = 0;
                        dv.RowFilter = sFilter;
                        if (dv.Count > 0)
                        {
                            grdZoneOffice.DataSource = dv;
                            ViewState["SubDivision"] = dv.ToTable();
                            grdZoneOffice.DataBind();

                        }
                        else
                        {

                            ShowEmptyGrid();
                        }
                    }
                    else
                    {
                        LoadSubDivisionOffices();
                    }


                }
            }
            catch (Exception ex)
            {
                clsException.LogError(ex.StackTrace,ex.Message, strFormCode, "grdZoneOffice_RowCommand");
            }
        }

        public void ShowEmptyGrid()
        {
            try
            {
                DataTable dt = new DataTable();
                DataRow newRow = dt.NewRow();
                dt.Rows.Add(newRow);
                dt.Columns.Add("SD_ID");
                dt.Columns.Add("CM_CIRCLE_NAME");
                dt.Columns.Add("DIV_NAME");
                dt.Columns.Add("SD_SUBDIV_NAME");
                dt.Columns.Add("SD_SUBDIV_CODE");
                dt.Columns.Add("SD_MOBILE");
                dt.Columns.Add("SD_HEAD_EMP");
               
                grdZoneOffice.DataSource = dt;
                grdZoneOffice.DataBind();

                int iColCount = grdZoneOffice.Rows[0].Cells.Count;
                grdZoneOffice.Rows[0].Cells.Clear();
                grdZoneOffice.Rows[0].Cells.Add(new TableCell());
                grdZoneOffice.Rows[0].Cells[0].ColumnSpan = iColCount;
                grdZoneOffice.Rows[0].Cells[0].Text = "No Records Found";

            }
            catch (Exception ex)
            {
               
                clsException.LogError(ex.StackTrace,ex.Message, strFormCode, "ShowEmptyGrid");

            }
        }


        #region Access Rights
        public bool CheckAccessRights(string sAccessType)
        {
            try
            {
                // 1---> ALL ; 2---> CREATE ;  3---> MODIFY/DELETE ; 4 ----> READ ONLY

                clsApproval objApproval = new clsApproval();

                objApproval.sFormName = "SubDivision";
                objApproval.sRoleId = objSession.RoleId;
                objApproval.sAccessType = "1" + "," + sAccessType;
                bool bResult = objApproval.CheckAccessRights(objApproval);
                if (bResult == false)
                {
                    if (sAccessType == "4")
                    {
                        Response.Redirect("~/UserRestrict.aspx", false);
                    }
                    else
                    {
                        ShowMsgBox("Sorry , You are not authorized to Access");
                    }
                }
                return bResult;

            }
            catch (Exception ex)
            {
                //lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "CheckAccessRights");
                return false;

            }
        }

        #endregion

        private void ShowMsgBox(string sMsg)
        {
            try
            {
                string sShowMsg = string.Empty;
                sShowMsg = "<script language=javascript> alert ('" + sMsg + "')</script>";
                this.Page.RegisterStartupScript("Msg", sShowMsg);
            }
            catch (Exception ex)
            {
                //lblErrormsg.Text = clsException.ErrorMsg();
                clsException.LogError(ex.StackTrace, ex.Message, strFormCode, "ShowMsgBox");
            }
        }
    }
}